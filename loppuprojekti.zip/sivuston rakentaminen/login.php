
<?php
// Aloitetaan istunto: tämä pitää tiedot (kuka on kirjautunut) muistissa
session_start();

// Otetaan tietokantayhteys käyttöön. 'yhteys.php' luo muuttujan $yhteys.
require_once __DIR__ . '/yhteys.php';
$yhteys->set_charset('utf8mb4');

// Virheilmoitusta varten: jos kirjautuminen epäonnistuu, tähän tulee teksti
$virhe = '';

// Käsitellään lomakkeen POST-lähetys
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Luetaan käyttäjän antamat tiedot ja poistetaan turhat välilyönnit
  $user = trim($_POST['username'] ?? '');
  $pass = trim($_POST['password'] ?? '');

  // Perusvalidaatio: molemmat kentät pitää olla täytetty
  if ($user === '' || $pass === '') {
    $virhe = 'Anna käyttäjätunnus ja salasana.';
  } else {
    // Haetaan tietokannasta tallennettu salasana (hash) käyttäjätunnuksella
    $stmt = $yhteys->prepare(""
    );
    $stmt = $yhteys->prepare(
        "SELECT salasana, rooli
         FROM kayttajat
         WHERE kayttajatunnus = ?
         LIMIT 1"
    );
    $stmt->bind_param('s', $user);
    $stmt->execute();
    $stmt->bind_result($hash, $rooli);

    if ($stmt->fetch() && password_verify($pass, $hash)) {
      // Tallennetaan session-muuttujiin nimi ja rooli, joita muu koodi lukee
      $_SESSION['kayttaja'] = $user;
      $_SESSION['kayttajat'] = $user;
      $_SESSION['rooli'] = (int)$rooli; // 1 = admin, 0 = tavallinen käyttäjä
      $_SESSION['1'] = (int)$rooli;   

      $stmt->close();
      // Onnistuneen kirjautumisen jälkeen ohjataan hakusivulle
      header('Location: haku.php');
      exit;
    } else {
      // Käyttäjätunnus tai salasana väärin
      $virhe = 'Väärä käyttäjätunnus tai salasana.';
    }
    $stmt->close();
  }
}
?>
<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8">
  <title>Kirjautuminen</title>
  <link rel="stylesheet" href="muntyyli.css">
</head>
<body>

<h2>Kirjaudu sisään</h2>

<?php if ($virhe): ?>
  <p style="color:red;"><?= htmlspecialchars($virhe) ?></p>
<?php endif; ?>

<form method="post">
  <label>Käyttäjätunnus</label><br>
  <input type="text" name="username" required autofocus><br><br>

  <label>Salasana</label><br>
  <input type="password" name="password" required><br><br>


  <input type="submit" value="Kirjaudu">
</form>
  <p>Ei vielä käyttäjää?</p>
  <a href="rekisteri.php">Rekisteröidy</a>
</p>

<p>
  <a href="tietosuoja.php">Tietosuojaseloste</a>
</p>

</body>
</html>
