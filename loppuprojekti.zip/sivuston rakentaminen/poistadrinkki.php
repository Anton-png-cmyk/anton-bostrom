<?php
// Aloitetaan istunto jotta voimme tarkistaa onko käyttäjä kirjautunut
session_start();

// Otetaan tietokantayhteys käyttöön
require_once "yhteys.php";
$yhteys->set_charset("utf8mb4");

// Suojataan sivu: jos sivu ei ole login tai rekisteröinti, varmistetaan
// että käyttäjä on kirjautunut sisään ennen kuin näytetään sisältö.
$page = basename($_SERVER['PHP_SELF']);

if (!in_array($page, ['login.php', 'rekisteri.php'])) {
    if (empty($_SESSION['kayttajat'])) {
        // Jos ei ole kirjautunut, ohjataan kirjautumissivulle
        header("Location: login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<title>Poista drinkki</title>

<link rel="stylesheet" href="muntyyli.css">

</head>
<body>

<?php
// Näytetään oikea navigaatio käyttäjän tilan ja roolin mukaan
if (empty($_SESSION['kayttaja'])) {
    include 'naviQuest.php'; // vieras
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
    include 'naviAdmin.php'; // ylläpitäjä
} else {
    include 'naviUser.php';  // tavallinen käyttäjä
}
?>


<h2>Poista drinkki</h2>

<?php
// Poiston käsittely: kun ylläpitäjä lähettää lomakkeen,
// korvataan id muuttujaan ja poistetaan rivi tietokannasta prepareratulla lauseella.
include 'yhteys.php';

if (isset($_POST['delete_id'])) {
    $id = intval($_POST['delete_id']);

    $stmt = $yhteys->prepare("DELETE FROM resepti WHERE resepti_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Haetaan kaikki reseptit listattavaksi, järjestettynä nimen mukaan
$result = $yhteys->query("SELECT resepti_id, nimi FROM resepti ORDER BY nimi");
?>

<?php while ($row = $result->fetch_assoc()): ?>

<div class="drinkkikortti">
    
    <span class="drinkkinimi">
        <strong><?= htmlspecialchars($row['nimi']); ?></strong>
    </span>

    <form method="POST" style="display:inline;">
        <input type="hidden" name="delete_id" value="<?= $row['resepti_id']; ?>">
        <button type="submit" class="poista-btn">Poista</button>
    </form>

</div>

<?php endwhile; ?>

</body>
</html>
