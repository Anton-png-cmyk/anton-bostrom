
<!-- naviQuest.php
     Navigaatio vierailijoille (ei kirjautuneille). Tarjoaa pääsyn
     kirjautumiseen tai rekisteröitymiseen jotta käyttäjä saa enemmän toimintoja.
-->
<ul class="nav">
  <!-- Siirry kirjautumissivulle -->
  <li><a href="login.php">Kirjaudu</a></li>
  <!-- Luo uusi käyttäjätili -->
  <li><a href="rekisteri.php">Rekisteröidy</a></li>
</ul>
