
<?php
/**
 * Tietokantayhteyden alustus.
 * - Muodostaa mysqli-yhteyden paikalliseen tietokantaan.
 * - Asettaa merkistökoodaukseksi utf8mb4.
 * Käytä tätä tiedostoa include/require -kutsulla muissa PHP-tiedostoissa.
 */
$palvelin  = "localhost";
$kayttaja  = "root";
$salasana  = "";
$tietokanta = "DrinkitAnton"; 

$yhteys = new mysqli($palvelin, $kayttaja, $salasana, $tietokanta);
if ($yhteys->connect_error) {
    die("Yhteys epäonnistui: " . $yhteys->connect_error);
}
$yhteys->set_charset("utf8mb4"); 

