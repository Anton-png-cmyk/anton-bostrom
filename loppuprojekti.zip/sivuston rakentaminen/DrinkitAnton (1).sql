-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 10.03.2026 klo 18:43
-- Palvelimen versio: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `DrinkitAnton`
--

-- --------------------------------------------------------

--
-- Rakenne taululle `aines`
--

CREATE TABLE `aines` (
  `aines_id` int(10) NOT NULL,
  `nimi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `aines`
--

INSERT INTO `aines` (`aines_id`, `nimi`) VALUES
(1, 'sokeri'),
(2, 'suola'),
(4, 'Rommi'),
(5, 'Vodka'),
(6, 'Sokerisiirappi'),
(7, 'Viski'),
(8, 'Tonic'),
(10, 'Gini'),
(11, 'Lime'),
(12, 'coca cola'),
(13, 'Sooda'),
(14, 'olut'),
(15, 'maito'),
(16, 'sandels'),
(17, 'villevallaton jäätelö'),
(18, 'bösee'),
(19, 'drvdrv');

-- --------------------------------------------------------

--
-- Rakenne taululle `kayttajat`
--

CREATE TABLE `kayttajat` (
  `kayttajatunnus` varchar(50) NOT NULL,
  `salasana` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `rooli` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `kayttajat`
--

INSERT INTO `kayttajat` (`kayttajatunnus`, `salasana`, `email`, `rooli`) VALUES
('admin', '$2y$10$0jRmVHcXbH/IUdnwZzdi6eOauf.uXEqiiNxg7rCt9/9X/EHRJAqcy', 'admin123@gmail.com', 1),
('user', '$2y$10$SW8DXQsgYJ8wp.HR1OS15.HvCkes2y3FAGgaqqjZuZ4A69jkSJdoy', 'user123@gmail.com', 0);

-- --------------------------------------------------------

--
-- Rakenne taululle `resepti`
--

CREATE TABLE `resepti` (
  `resepti_id` int(10) NOT NULL,
  `nimi` varchar(50) NOT NULL,
  `juomalaji` varchar(50) DEFAULT NULL,
  `valmistusohje` varchar(200) DEFAULT NULL,
  `hyvaksytty` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `resepti`
--

INSERT INTO `resepti` (`resepti_id`, `nimi`, `juomalaji`, `valmistusohje`, `hyvaksytty`) VALUES
(28, 'danielin erikoinen', 'alkoholi', 'sekoita', 1),
(31, 'Niklaksen erikoinen', 'börsta', 'sekoitetaan', 1);

-- --------------------------------------------------------

--
-- Rakenne taululle `reseptin_aines_maara`
--

CREATE TABLE `reseptin_aines_maara` (
  `resepti_id` int(10) NOT NULL,
  `aines_id` int(10) NOT NULL,
  `maara` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Vedos taulusta `reseptin_aines_maara`
--

INSERT INTO `reseptin_aines_maara` (`resepti_id`, `aines_id`, `maara`) VALUES
(28, 5, '4cl'),
(31, 11, '1kpl'),
(31, 16, '5cl'),
(31, 17, '2 lusikallista');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aines`
--
ALTER TABLE `aines`
  ADD PRIMARY KEY (`aines_id`);

--
-- Indexes for table `kayttajat`
--
ALTER TABLE `kayttajat`
  ADD PRIMARY KEY (`kayttajatunnus`);

--
-- Indexes for table `resepti`
--
ALTER TABLE `resepti`
  ADD PRIMARY KEY (`resepti_id`);

--
-- Indexes for table `reseptin_aines_maara`
--
ALTER TABLE `reseptin_aines_maara`
  ADD PRIMARY KEY (`resepti_id`,`aines_id`),
  ADD KEY `reseptin_aines_maara_ibfk_2` (`aines_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aines`
--
ALTER TABLE `aines`
  MODIFY `aines_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `resepti`
--
ALTER TABLE `resepti`
  MODIFY `resepti_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Rajoitteet vedostauluille
--

--
-- Rajoitteet taululle `reseptin_aines_maara`
--
ALTER TABLE `reseptin_aines_maara`
  ADD CONSTRAINT `reseptin_aines_maara_ibfk_1` FOREIGN KEY (`resepti_id`) REFERENCES `resepti` (`resepti_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reseptin_aines_maara_ibfk_2` FOREIGN KEY (`aines_id`) REFERENCES `aines` (`aines_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
