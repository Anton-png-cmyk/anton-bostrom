
<?php
/**
 * Haku-sivu: käsittelee reseptihakua ja näyttää hakutulokset.
 * - Lukee hakulomakkeen syötteen (nimi tai ainesosa).
 * - Hakee reseptit tietokannasta ja ryhmittelee ainesosat.
 */
session_start();
require_once "yhteys.php";
$yhteys->set_charset("utf8mb4");


# ========== NAVI + KIRJAUTUMISPAKKO ==========

$page = basename($_SERVER['PHP_SELF']);

# sivut joihin pääsee ilman kirjautumista
if (!in_array($page, ['login.php', 'rekisteri.php'])) {
    if (empty($_SESSION['kayttajat'])) {
        header("Location: login.php");
        exit;
    }
}

// navien näkyminen rooleittain
if (empty($_SESSION['kayttaja'])) {
    include 'naviQuest.php';
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
    include 'naviAdmin.php';
} else {
    include 'naviUser.php';
}


# ---Haku---

$q = trim($_POST['q'] ?? '');
$tyyppi = $_POST['tyyppi'] ?? 'nimi';
$data = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($q === '') {
        // Kaikki reseptit
        $sql = "
            SELECT d.resepti_id, d.nimi, d.juomalaji, d.valmistusohje,
                   a.nimi AS aines, ram.maara
            FROM resepti AS d
            LEFT JOIN reseptin_aines_maara AS ram ON ram.resepti_id = d.resepti_id
            LEFT JOIN aines AS a ON a.aines_id = ram.aines_id
            ORDER BY d.nimi
        ";
        $stmt = $yhteys->prepare($sql);

    } elseif ($tyyppi === 'nimi') {
        // Hae nimellä
        $sql = "
            SELECT d.resepti_id, d.nimi, d.juomalaji, d.valmistusohje,
                   a.nimi AS aines, ram.maara
            FROM resepti AS d
            LEFT JOIN reseptin_aines_maara AS ram ON ram.resepti_id = d.resepti_id
            LEFT JOIN aines AS a ON a.aines_id = ram.aines_id
            WHERE d.nimi LIKE ?
            ORDER BY d.nimi
        ";
        $stmt = $yhteys->prepare($sql);
        $like = "%$q%";
        $stmt->bind_param("s", $like);

    } else {
        // Hae ainesosalla
        $sql = "
            SELECT d.resepti_id, d.nimi, d.juomalaji, d.valmistusohje,
                   a.nimi AS aines, ram.maara
            FROM resepti AS d
            JOIN reseptin_aines_maara AS ram ON ram.resepti_id = d.resepti_id
            JOIN aines AS a ON a.aines_id = ram.aines_id
            WHERE a.nimi LIKE ?
            ORDER BY d.nimi
        ";
        $stmt = $yhteys->prepare($sql);
        $like = "%$q%";
        $stmt->bind_param("s", $like);
    }

    $stmt->execute();
    $r = $stmt->get_result();

    // Ryhmittely resepti_id
    while ($row = $r->fetch_assoc()) {
        $id = $row['resepti_id'];
        if (!isset($data[$id])) {
            $data[$id] = [
                'nimi' => $row['nimi'],
                'juomalaji' => $row['juomalaji'],
                'ohje' => $row['valmistusohje'],
                'ainekset' => []
            ];
        }
        if (!empty($row['aines'])) {
            $teksti = $row['aines'] .
                   ($row['maara'] !== null && $row['maara'] !== '' 
                        ? ' ' . $row['maara'] 
                        : '');
            $data[$id]['ainekset'][] = $teksti;
        }
    }

    $stmt->close();
}
?>
<!doctype html>
<html lang="fi">
<head>
<meta charset="utf-8">
<title>Haku</title>
<link rel="stylesheet" href="muntyyli.css">
</head>

<body>

<h2>Haku</h2>

<form method="post" class="lomake">
  <input type="text" name="q" placeholder="Haku" value="<?= htmlspecialchars($q) ?>">

  <div class="haku-radios">
    <label><input type="radio" name="tyyppi" value="nimi"  <?= $tyyppi==='nimi'?'checked':''; ?>> Nimi</label>
    <label><input type="radio" name="tyyppi" value="aines" <?= $tyyppi==='aines'?'checked':''; ?>> Ainesosa</label>
  </div>

  <br><br>
  <input type="submit" value="Haku">
</form>

<?php if (!empty($data)): ?>
  <?php foreach ($data as $drinkki): ?>
    <div class="drinkkikortti">
      <p><b>Nimi:</b> <?= htmlspecialchars($drinkki['nimi']) ?></p>
      <p><b>Juomalaji:</b> <?= htmlspecialchars($drinkki['juomalaji']) ?></p>
      <p><b>Ainesosat:</b></p>

      <ul class="aines-rivi">
        <?php foreach ($drinkki['ainekset'] as $a): ?>
          <li><?= htmlspecialchars($a) ?></li>
        <?php endforeach; ?>
      </ul>

      <p><b>Valmistusohje:</b><br><?= nl2br(htmlspecialchars($drinkki['ohje'])) ?></p>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
