<?php
// Aloitetaan istunto ja otetaan tietokantayhteys
session_start();
require_once __DIR__ . '/yhteys.php';
$yhteys->set_charset('utf8mb4');


$rooli = null;
if (isset($_SESSION['rooli'])) {
    $rooli = (int)$_SESSION['rooli'];
} elseif (isset($_SESSION['1'])) {
    $rooli = (int)$_SESSION['1'];
}

// Suojataan sivu: vaaditaan kirjautuminen ja admin-rooli (1)
if (empty($_SESSION['kayttaja']) || $rooli !== 1) {
    header('Location: login.php');
    exit;
}


// Käyttäjän poistokäsittely (vain admin voi päästä tänne)
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $del = $_POST['delete_user'];
    // Estetään itseensä osoittava poisto
    if ($del === $_SESSION['kayttaja']) {
        $msg = 'Et voi poistaa itseäsi.';
    } else {
        $stmt = $yhteys->prepare('DELETE FROM kayttajat WHERE kayttajatunnus = ?');
        $stmt->bind_param('s', $del);
        if ($stmt->execute()) {
            $msg = 'Käyttäjä poistettu.';
        } else {
            $msg = 'Poisto epäonnistui.';
        }
        $stmt->close();
    }
}

// Haetaan lista kaikista käyttäjistä, näytetään adminille
$res = $yhteys->query('SELECT kayttajatunnus, rooli FROM kayttajat ORDER BY kayttajatunnus ASC');
?>
<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8">
  <title>Poista käyttäjä</title>
  <link rel="stylesheet" href="muntyyli.css">
  <meta name="viewport" content="width=device-width,initial-scale=1">
</head>
<body>

<?php
// role-based nav
if (empty($_SESSION['kayttaja'])) {
    include 'naviQuest.php';
} elseif ($rooli === 1) {
    include 'naviAdmin.php';
} else {
    include 'naviUser.php';
}
?>

<h2>Poista käyttäjä</h2>
<?php if ($msg): ?><p><?= htmlspecialchars($msg) ?></p><?php endif; ?>

<?php while ($r = $res->fetch_assoc()): ?>
    <div class="drinkkikortti">
        <p><b><?= htmlspecialchars($r['kayttajatunnus']) ?></b></p>
        <p>Rooli: <?= (int)$r['rooli'] === 1 ? 'Admin' : 'User' ?></p>

        <?php if ($r['kayttajatunnus'] !== $_SESSION['kayttaja']): ?>
            <form method="post" style="display:inline;">
                <input type="hidden" name="delete_user" value="<?= htmlspecialchars($r['kayttajatunnus']) ?>">
                <button type="submit" class="poista-btn">Poista</button>
            </form>
        <?php else: ?>
            <p><i>Et voi poistaa itseäsi</i></p>
        <?php endif; ?>
    </div>
<?php endwhile; ?>

</body>
</html>
