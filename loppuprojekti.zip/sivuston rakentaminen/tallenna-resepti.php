
<?php
require_once __DIR__ . '/yhteys.php';
$yhteys->set_charset('utf8mb4');

function clean($s) { return trim((string)$s); }

// a) Palataan siihen sivuun, josta lomake lähti
$return = basename($_SERVER['HTTP_REFERER'] ?? 'lisays.php');

// b) Lue tiedot
$nimi       = clean($_POST['nimi'] ?? '');
$juomalaji  = clean($_POST['juomalaji'] ?? '');
$ohjeet     = clean($_POST['ohjeet'] ?? '');
$hyvaksytty = (int)($_POST['hyvaksytty'] ?? 0);

$ainesNimet = $_POST['aines_nimi'] ?? [];
$maarat     = $_POST['maara'] ?? [];

// c) Lisää resepti
$stmt = $yhteys->prepare("
  INSERT INTO resepti (nimi, juomalaji, valmistusohje, hyvaksytty)
  VALUES (?, ?, ?, ?)
");
$stmt->bind_param("sssi", $nimi, $juomalaji, $ohjeet, $hyvaksytty);
$stmt->execute();

$resepti_id = $stmt->insert_id;

// d) Lisää ainekset
$sel = $yhteys->prepare("SELECT aines_id FROM aines WHERE LOWER(nimi)=LOWER(?) LIMIT 1");
$ins = $yhteys->prepare("INSERT INTO aines (nimi) VALUES (?)");
$link = $yhteys->prepare("
  INSERT INTO reseptin_aines_maara (resepti_id, aines_id, maara)
  VALUES (?, ?, ?)
");

for ($i=0; $i<max(count($ainesNimet), count($maarat)); $i++) {
    $aines = clean($ainesNimet[$i] ?? '');
    $maara = clean($maarat[$i] ?? '');

    if ($aines === '' && $maara === '') continue;

    $sel->bind_param("s", $aines);
    $sel->execute();
    $sel->bind_result($aid);

    if (!$sel->fetch()) {
        $sel->free_result();
        $ins->bind_param("s", $aines);
        $ins->execute();
        $aid = $ins->insert_id;
    }
    $sel->free_result();

    $link->bind_param("iis", $resepti_id, $aid, $maara);
    $link->execute();
}
header("Location: $return?ok=1");
exit;
