<?php
/**
 * Uuden reseptin lisäyssivu (lomake).
 * - Näyttää lomakkeen reseptin lisäämistä varten.
 * - Lomake lähettää tiedot `tallenna-resepti.php`-tiedostolle tallennusta varten.
 */
// Aloitetaan PHP-istunto: tämä "muistaa" kuka on kirjautuneena
session_start();

// Otetaan yhteys tietokantaan. Tämä tiedosto luo muuttujan $yhteys,
// jota käytämme tarvittaessa tietojen tallentamiseen.
require_once "yhteys.php";
$yhteys->set_charset("utf8mb4");

$page = basename($_SERVER['PHP_SELF']);

if (!in_array($page, ['login.php', 'rekisteri.php'])) {
  if (empty($_SESSION['kayttajat'])) {
    header("Location: login.php");
    exit;
  }
}
?>
<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lisää resepti</title>

  <link rel="stylesheet" href="muntyyli.css">
</head>
<body>

<?php
// navien näkyminen rooleittain
// Näytetään oikea yläpalkin valikko käyttäjän mukaan:
// - Jos ei ole kirjautunut -> vierasnavigaatio (naviQuest)
// - Jos on ylläpitäjä (rooli 1) -> ylläpitäjän navigaatio (naviAdmin)
// - Muuten tavallinen käyttäjänavigaatio (naviUser)
if (empty($_SESSION['kayttaja'])) {
  include 'naviQuest.php';
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
  include 'naviAdmin.php';
} else {
  include 'naviUser.php';
}
?>


<form id="reseptiForm" class="lomake"
      action="/anton/sivuston%20rakentaminen/tallenna-resepti.php"
      method="post" novalidate>

  <h2>Lisää uusi resepti</h2>

  <!-- Lomakkeen kentät:
    - 'nimi' on pakollinen (lomake estää lähetyksen, jos tyhjä)
    - 'juomalaji' on vapaaehtoinen lisätieto
  -->
  <input type="text" name="nimi" id="nimi" placeholder="Nimi" required />
  <input type="text" name="juomalaji" id="juomalaji" placeholder="Juomalaji" />


  <!-- Tähän taulukkomuotoiseen alueeseen lisätään JavaScriptillä
    raaka-aine- ja määrä-kenttiä kahteen sarakkeeseen.
  -->
  <div class="aines-grid" style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin:16px auto; max-width: 900px;">
    
    <div>
      <h3>Raaka-aine:</h3>
      <div id="aines_col"></div>
    </div>

    <div>
      <h3>Raaka-aineen määrä</h3>
      <div id="maara_col"></div>
    </div>

  </div>

  
<div style="margin:0 auto; max-width:900px; text-align:right;">
  <!-- Nämä napit lisäävät/poistavat rivejä ilman sivun uudelleenlatausta -->
  <button type="button" id="lisaaRiviBtn">+ Lisää rivi</button>
  <button type="button" id="poistaRiviBtn" style="background:#8b1e1e;color:white;">Poista rivi</button>
</div>

  <datalist id="aines-ehdotukset">
    <option value="Vodka"></option>
    <option value="Gini"></option>
    <option value="Lime"></option>
    <option value="Sooda"></option>
  </datalist>

  <textarea name="ohjeet" placeholder="Ohjeet"></textarea>
  
  <!-- Piilotettu kenttä kertoo tallennettaessa, onko resepti automaattisesti hyväksytty -->
  <input type="hidden" name="hyvaksytty" value="1" />

  <input type="submit" value="LISÄÄ RESEPTI" />
  <p id="virheViesti" style="color:#ff8a80;"></p>
</form>



<script>
(function(){
  const ainesCol = document.getElementById('aines_col');
  const maaraCol = document.getElementById('maara_col');
  const addBtn   = document.getElementById('lisaaRiviBtn');
  


  function createRow(aVal = '', mVal = '') {
    const a = document.createElement('input');
    a.type = 'text';
    a.name = 'aines_nimi[]';
    a.setAttribute('list', 'aines-ehdotukset');
    a.placeholder = 'esim. Vodka';
    a.style.marginBottom = '8px';
    a.value = aVal;

    const m = document.createElement('input');
    m.type = 'text';
    m.name = 'maara[]';
    m.placeholder = 'esim. 4 cl';
    m.style.marginBottom = '8px';
    m.value = mVal;

    ainesCol.appendChild(a);
    maaraCol.appendChild(m);
  }

  createRow();
  createRow();
  createRow();
  
  addBtn.addEventListener('click', () => createRow());


document.getElementById('poistaRiviBtn').addEventListener('click', () => {
    const aines = document.querySelectorAll('input[name="aines_nimi[]"]');
    const maarat = document.querySelectorAll('input[name="maara[]"]');

    if (aines.length <= 1) {
        alert("Vähintään yksi rivi on oltava.");
        return;
    }

   
    aines[aines.length - 1].remove();
    maarat[maarat.length - 1].remove();
});




  document.getElementById('reseptiForm').addEventListener('submit', function (e) {
    const virhe = document.getElementById('virheViesti');
    virhe.textContent = '';

    const nimi = document.getElementById('nimi').value.trim();
    if (!nimi) {
      e.preventDefault();
      virhe.textContent = 'Nimi ei saa olla tyhjä.';
      return;
    }

    const ainesKentat = Array.from(document.querySelectorAll('input[name="aines_nimi[]"]'));
    const maaraKentat = Array.from(document.querySelectorAll('input[name="maara[]"]'));

    const onkoYhtaanAines = ainesKentat.some(i => i.value.trim() !== '');
    const onkoYhtaanMaara = maaraKentat.some(i => i.value.trim() !== '');

    if (!onkoYhtaanAines && !onkoYhtaanMaara) {
      e.preventDefault();
      virhe.textContent = 'Lisää vähintään yksi raaka-aine tai sen määrä.';
      return;
    }

    for (let i = 0; i < Math.min(ainesKentat.length, maaraKentat.length); i++) {
      if (maaraKentat[i].value.trim() && !ainesKentat[i].value.trim()) {
        e.preventDefault();
        virhe.textContent = 'Jos määrä on annettu, raaka-aine puuttuu.';
        return;
      }
    }
  });
})();
</script>

</body>
</html>
