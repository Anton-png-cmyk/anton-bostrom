
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tietosuojaseloste</title>
    <link rel="stylesheet" href="muntyyli.css">
</head>
<body class="tietosuoja">

<div class="container tietosuoja">

        <div class="tietosuoja-header">
            <h1>Tietosuojaseloste</h1>
        </div>

    <section>
    <section>
        <h2>1. Rekisterinpitäjä</h2>
        <p>
            Drinkkiarkisto<br>
            Upseerinkatu 11<br>
            02230 Espoo<br>
            Sähköposti: tietosuoja@drinkkiarkisto.fi
        </p>
    </section>

    <section>
        <h2>2. Oikeusperusta</h2>
        <p>
            Henkilötietojen käsittely perustuu rekisteröidyn suostumukseen sekä
            sopimuksen tekemisen ja täytäntöönpanon välttämättömyyteen.
        </p>
    </section>

    <section>
        <h2>3. Henkilötietojen käsittelyn tarkoitus</h2>
        <p>
            Henkilötietoja käsitellään asiakassuhteen hoitamiseksi,
            yhteydenottoihin vastaamiseksi sekä lakisääteisten velvoitteiden
            täyttämiseksi.
        </p>
    </section>

    <section>
        <h2>4. Käsiteltävät henkilötiedot</h2>
            <ul>
                <li>Nimi</li>
                <li>Sähköpotiosoite</li>
                <li>Puhelinnumero</li>
                </li>Yhteydenotot sisältö</li>
            </ul>
    </section>

    <section>
        <h2>5. Henkilötietojen säilytysaika</h2>
        <p>
            Henkilötietoja säilytetään vain niin kauan kuin tarpeen tai lain
            edellyttämän ajan.
        </p>
    </section>

    <section>
        <h2>6. Henkilötietojen luovutukset</h2>
        <p>
            Tietoja ei luovuteta ulkopuolisille, ellei laki sitä edellytä.
        </p>
    </section>

    <section>
      <h2>7. Rekisteröidyn oikeudet</h2>
            <ul> 
                <li>Oikeus saada pääsy omiin tietoihin</li>
                <li>Oikeus tietojen oikaisemiseen</li>
                <li>Oikeus tietojen poistamiseen</li>
                <li>Oikeis käsittelyn rajoittamiseen</li>
                <li>Oikeus tehdä valitus valvontaviranomaiselle</li>
            </ul>
    </section>

    <section>
        <h2>9. Yhteystiedot</h2>
        <p>
            Voit ottaa yhteyttä rekisterinpitäjään yllä mainituilla yhteystiedoilla.
        </p>
    </section>

    <section>
        <h2>10. Muutokset tietosuojaselosteeseen</h2>
        <p>
            Tätä tietosuojaselostetta voidaan päivittää tarvittaessa.
            Päivitetty versio julkaistaan tällä sivulla.
        </p>
    </section>

    <footer>
        <p>&copy; 2026 Drinkkiarkisto. Kaikki oikeudet pidätetään.</p>
    </footer>

</div>

</body>
</html>
