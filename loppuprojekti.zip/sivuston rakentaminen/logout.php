<?php
/**
 * Kirjaa käyttäjän ulos.
 * - Tyhjentää kaikki session-muuttujat ja tuhoaa sessionin palvelimella.
 * - Ohjaa käyttäjän takaisin kirjautumissivulle.
 */
session_start();
session_unset(); 
session_destroy();

header("Location: login.php");
exit;