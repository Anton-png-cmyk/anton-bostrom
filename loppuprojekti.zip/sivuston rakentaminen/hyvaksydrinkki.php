<?php
session_start();
require_once "yhteys.php";
$yhteys->set_charset("utf8mb4");

$page = basename($_SERVER['PHP_SELF']);

if (!in_array($page, ['login.php', 'rekisteri.php'])) {
    if (empty($_SESSION['kayttajat'])) {
        header("Location: login.php");
        exit;
    }
}
?>
<?php
session_start();


$db = new mysqli("localhost", "root", "", "DrinkitAnton");
$db->set_charset("utf8mb4");

// --- Hyväksy ---
if (isset($_POST['hyvaksy'])) {
    $id = (int)$_POST['resepti_id'];
    $db->query("UPDATE resepti SET hyvaksytty = 1 WHERE resepti_id = $id");
    header("Location: hyvaksydrinkki.php");
    exit;
}

if (isset($_POST['hylkaa'])) {
    $id = (int)$_POST['resepti_id'];

    
    $db->query("DELETE FROM reseptin_aines_maara WHERE resepti_id = $id");

    // Poista itse resepti
    $db->query("DELETE FROM resepti WHERE resepti_id = $id");

    header("Location: hyvaksydrinkki.php");
    exit;
}

$ehdotukset = $db->query("SELECT * FROM resepti WHERE hyvaksytty = 0");
?>
<!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<title>Hyväksy reseptit</title>
</head>
<body>
<?php
// Näytetään navit roolin mukaan
if (empty($_SESSION['kayttaja'])) {
    include 'naviQuest.php';
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
    include 'naviAdmin.php';
} else {
    include 'naviUser.php';
}
?>

<link rel="stylesheet" href="muntyyli.css">
<h1>Hyväksymättömät reseptit</h1>

<?php if ($ehdotukset->num_rows === 0): ?>
    <p>Ei hyväksymättömiä ehdotuksia.</p>
<?php endif; ?>

<?php while ($row = $ehdotukset->fetch_assoc()): ?>
    <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
        <b><?= htmlspecialchars($row['nimi']) ?></b><br>
        Juomalaji: <?= htmlspecialchars($row['juomalaji']) ?><br><br>

        <form method="post" style="display:inline;">
            <input type="hidden" name="resepti_id" value="<?= $row['resepti_id'] ?>">
            <button type="submit" name="hyvaksy">Hyväksy</button>
        </form>

        <form method="post" style="display:inline;">
            <input type="hidden" name="resepti_id" value="<?= $row['resepti_id'] ?>">
            <button type="submit" name="hylkaa">Hylkää</button>
        </form>
    </div>
<?php endwhile; ?>

</body>
</html>
