<?php
session_start();
require_once "yhteys.php";
$yhteys->set_charset("utf8mb4");

$page = basename($_SERVER['PHP_SELF']);

if (!in_array($page, ['login.php', 'rekisteri.php'])) {
    if (empty($_SESSION['kayttajat'])) {
        header("Location: login.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lisää drinkki</title>
    <link rel="stylesheet" href ="muntyyli.css">
</head>
<body>

<?php
// role-based nav
if (empty($_SESSION['kayttaja'])) {
    include 'naviQuest.php';
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
    include 'naviAdmin.php';
} else {
    include 'naviUser.php';
}
?>

<!-- sivun oma sisältö -->

    <div class="lisaaAinesosat">
        <h2>Lisää aines </h2>

        <form action="lisaaAines.php" method="post">
            <input type="text" name="ainesLisays" placeholder="Anna aineksen nimi" required>
            <input type="submit" name="lisays" value="Lisää aines">
        </form>
    </div>
</body>
</html>


<?php
    include_once("yhteys.php");
    //Kun lisää nappia painetaan
    if(isset($_POST["lisays"])) {
        $nimi = $_POST['ainesLisays'];
        if(empty($nimi)) {
            echo"<h4>Anna lisättävän aineksen nimi!</h4>";
        } else {
            $haku ="SELECT * FROM aines WHERE Nimi = '$nimi'";
            $tulos = $yhteys->query($haku);

            if ($tulos -> num_rows > 0) {
                echo "<h4>Aines on jo tietokannassa!</h4>";
            } else {
                $lisayssql = "INSERT INTO aines (Nimi) VALUES ('$nimi')";
                $result = $yhteys -> query($lisayssql);
                if($result === TRUE) {
                    echo "<h4>Aines lisätty onnistuneesti!</h4>";
                } else {
                    echo "<h4>Virhe aineksen lisäämisessä: </h4>";
                }
            }
        }
    }
//ainesten listaaminen
?>
<div class="ainesLista">
    <h3> Ainesosat:</h3>
    <?php
        $hakusql = "SELECT * FROM aines ORDER BY Nimi";
        $tulos = $yhteys->query($hakusql);

        if ($tulos -> num_rows > 0) {
            //Tulostetaan jokainen rivi
            while ($rivi = $tulos -> fetch_assoc()) {
                echo "<li>".htmlspecialchars($rivi['nimi'])."</li>";
            }
        } else {
            echo "<p>Ei aineksia</p>";
        }
    ?>
