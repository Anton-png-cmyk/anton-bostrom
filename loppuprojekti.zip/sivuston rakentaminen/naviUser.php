
<!-- naviUser.php
		 Navigaatio kirjautuneelle tavalliselle käyttäjälle.
		 Tämä tarjoaa linkit ehdottaa drinkkiä, hakea reseptejä ja kirjautua ulos.
-->
<ul class="nav">
	<!-- Lomake ehdottaa uutta reseptiä ylläpidolle -->
	<li><a href="ehdotus.php">Ehdota drinkkiä</a></li>
	<!-- Hae reseptejä hakutoiminnolla -->
	<li><a href="haku.php">Drinkkihaku</a></li>
	<!-- Kirjaudu ulos (session tyhjennys) -->
	<li><a href="logout.php">Kirjaudu ulos</a></li>
</ul>