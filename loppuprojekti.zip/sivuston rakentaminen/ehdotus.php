<?php
/**
 * Ehdota resepti -sivu
 * - Kirjautunut käyttäjä voi ehdottaa uutta reseptiä täyttämällä lomakkeen.
 * - Lomake lähettää tiedot palvelimelle, joka tallentaa ehdotuksen tietokantaan.
 */
// Aloitetaan sessio ja otetaan tietokantayhteys
session_start();
require_once "yhteys.php";             // yhteys.php luo $yhteys-muuttujan
$yhteys->set_charset("utf8mb4");       // varmistetaan oikeat merkit

// Estetään ei-kirjautuneita pääsemästä sivuille (paitsi login ja rekisteri)
$page = basename($_SERVER['PHP_SELF']);
if (!in_array($page, ['login.php', 'rekisteri.php'])) {
  if (empty($_SESSION['kayttaja'])) {
    // uudelleenohjataan kirjautumissivulle jos käyttäjä ei ole kirjautunut
    header("Location: login.php");
    exit;
  }
}
?>
<!doctype html>
<html lang="fi">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Lisää resepti</title>

  <link rel="stylesheet" href="muntyyli.css">
</head>
<body>

<?php
// Valitaan navigaatio käyttäjän roolin mukaan
// - Jos ei ole kirjautunut: vieras (naviQuest.php)
// - Jos rooli == 1: ylläpitäjä (naviAdmin.php)
// - Muuten normaalikäyttäjä (naviUser.php)
if (empty($_SESSION['kayttaja'])) {
  include 'naviQuest.php';
} elseif (isset($_SESSION['rooli']) && (int)$_SESSION['rooli'] === 1) {
  include 'naviAdmin.php';
} else {
  include 'naviUser.php';
}
?>


<!-- Lomake, joka lähettää reseptin palvelimelle tallenna-resepti.php -->
<form id="reseptiForm" class="lomake"
      action="/anton/sivuston%20rakentaminen/tallenna-resepti.php"
      method="post" novalidate>

  <h2>Ehdota uutta drinkkiä</h2>

  <!-- Reseptin peruskentät -->
  <input type="text" name="nimi" id="nimi" placeholder="Nimi" required />
  <input type="text" name="juomalaji" id="juomalaji" placeholder="Juomalaji" />


  <div class="aines-grid" style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin:16px auto; max-width: 900px;">
    
    <div>
      <h3>Raaka-aine:</h3>
      <div id="aines_col"></div>
    </div>

    <div>
      <h3>Raaka-aineen määrä</h3>
      <div id="maara_col"></div>
    </div>

  </div>

  
<div style="margin:0 auto; max-width:900px; text-align:right;">
  <button type="button" id="lisaaRiviBtn">+ Lisää rivi</button>
  <button type="button" id="poistaRiviBtn" style="background:#8b1e1e;color:white;">Poista rivi</button>
</div>

  <!-- Valmiita ehdotuksia raaka-aineille, joita voidaan käyttää drinkissä -->
  <datalist id="aines-ehdotukset">
    <option value="Vodka"></option>
    <option value="Gini"></option>
    <option value="Lime"></option>
    <option value="Sooda"></option>
  </datalist>

  <textarea name="ohjeet" placeholder="Ohjeet"></textarea>
  
  <input type="hidden" name="hyvaksytty" value="0" />

  <input type="submit" value="LISÄÄ RESEPTI" />
  <p id="virheViesti" style="color:#ff8a80;"></p>
</form>

<script>
(function(){
  const ainesCol = document.getElementById('aines_col');
  const maaraCol = document.getElementById('maara_col');
  const addBtn   = document.getElementById('lisaaRiviBtn');
  const removeBtn = document.getElementById('poistaRiviBtn');

  if (!ainesCol || !maaraCol) return; // safety

  function createRow(aVal = '', mVal = '') {
    const a = document.createElement('input');
    a.type = 'text';
    a.name = 'aines_nimi[]';
    a.setAttribute('list', 'aines-ehdotukset');
    a.placeholder = 'esim. Vodka';
    a.className = 'dynamic-input';
    a.value = aVal;

    const m = document.createElement('input');
    m.type = 'text';
    m.name = 'maara[]';
    m.placeholder = 'esim. 4 cl';
    m.className = 'dynamic-input';
    m.value = mVal;

    ainesCol.appendChild(a);
    maaraCol.appendChild(m);
  }


  if (ainesCol.querySelectorAll('input').length === 0) {
    createRow(); createRow(); createRow();
  }

  if (addBtn) addBtn.addEventListener('click', function(e){ e.preventDefault(); createRow(); });

  if (removeBtn) removeBtn.addEventListener('click', function(e){
    e.preventDefault();
    const aines = ainesCol.querySelectorAll('input[name="aines_nimi[]"]');
    const maarat = maaraCol.querySelectorAll('input[name="maara[]"]');
    if (aines.length <= 1) { alert('Vähintään yksi rivi on oltava.'); return; }
    aines[aines.length - 1].remove();
    maarat[maarat.length - 1].remove();
  });

  const form = document.getElementById('reseptiForm');
  if (form) form.addEventListener('submit', function(e){
    const virhe = document.getElementById('virheViesti'); if (virhe) virhe.textContent = '';
    const nimi = document.getElementById('nimi').value.trim();
    if (!nimi) { e.preventDefault(); if (virhe) virhe.textContent = 'Nimi ei saa olla tyhjä.'; return; }

    const ainesKentat = Array.from(document.querySelectorAll('input[name="aines_nimi[]"]'));
    const maaraKentat = Array.from(document.querySelectorAll('input[name="maara[]"]'));
    const onkoYhtaanAines = ainesKentat.some(i => i.value.trim() !== '');
    const onkoYhtaanMaara = maaraKentat.some(i => i.value.trim() !== '');
    if (!onkoYhtaanAines && !onkoYhtaanMaara) { e.preventDefault(); if (virhe) virhe.textContent = 'Lisää vähintään yksi raaka-aine tai sen määrä.'; return; }

    for (let i = 0; i < Math.min(ainesKentat.length, maaraKentat.length); i++) {
      if (maaraKentat[i].value.trim() && !ainesKentat[i].value.trim()) { e.preventDefault(); if (virhe) virhe.textContent = 'Jos määrä on annettu, raaka-aine puuttuu.'; return; }
    }
  });

})();
</script>
