
<!-- naviAdmin.php
     Ylläpidon navigaatio: näytetään, kun käyttäjällä on admin-rooli.
     Kommentit alla kertovat lyhyesti mitä kukin linkki tekee.
-->
<ul class="nav">
  <!-- Lisää uusi drinkki tietokantaan -->
  <li><a href="lisays.php">Lisää drinkki</a></li>
  <!-- Lisää uusi raaka-aine aineslistaan -->
  <li><a href="lisaaAines.php">Lisää aines</a></li>
  <!-- Käyttäjät voi hakea drinkkejä -->
  <li><a href="haku.php">Drinkkihaku</a></li>
  <!-- Sivuston ylläpitäjä hyväksyy ehdotetut drinkit täällä -->
  <li><a href="hyvaksydrinkki.php">Hyväksy drinkit</a></li>
  <!-- Käyttäjien hallinta: poista käyttäjiä -->
  <li><a href="poistakayttaja.php">Poista käyttäjä</a></li>
  <!-- Kirjautumisen lopetus (tyhjentää session) -->
  <li><a href="logout.php">Kirjaudu ulos</a></li>
</ul>
