
<?php
// Näytetään kaikki virheet kehitysvaiheessa
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Tietokantayhteys ja istunnon aloitus
require_once "yhteys.php";
session_start();
$yhteys->set_charset("utf8mb4");

// Viesti käyttäjälle (onnistui/epäonnistui)
$msg = "";

// Lomakkeen käsittely POST-metodilla
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Luetaan lomakkeelta käyttäjätunnus ja salasana
    $user = trim($_POST['kayttaja'] ?? '');
    $pass = trim($_POST['salasana'] ?? '');

    // Perustarkistus: käyttäjätunnus ei saa olla tyhjä ja salasana vähintään 8 merkkiä
    if ($user === '' || strlen($pass) < 8) {
        $msg = "Käyttäjänimi tai salasana puuttuu.";
    } else {

        // Tarkistetaan ettei sama käyttäjätunnus ole jo olemassa
        $stmt = $yhteys->prepare("SELECT 1 FROM kayttajat WHERE kayttajatunnus=? LIMIT 1");
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $stmt->store_result();              
        if ($stmt->num_rows > 0) {          
            $msg = "Käyttäjä on jo olemassa.";

        } else {
            // Luodaan salasana-hash turvallisesti ennen tallennusta
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $rooli = 0; // oletuksena tavallinen käyttäjä

            $email = trim($_POST['email'] ?? '');

            // Tallennetaan uusi käyttäjä tietokantaan
            $stmt = $yhteys->prepare(
                "INSERT INTO kayttajat (kayttajatunnus, salasana, email, rooli)
                VALUES (?, ?, ?, ?)"
            );
            $stmt->bind_param("sssi", $user, $hash,$email,$rooli);
            $stmt->execute();
            $msg = "Rekisteröityminen onnistui!";
        }
    }
}
?>

<!doctype html>
<html>
<head><meta charset="utf-8"><title>Rekisteröinti</title></head>
<link rel="stylesheet" href="muntyyli.css">
<body>
<h2>Rekisteröidy</h2>

<p><?= $msg ?></p>

<form method="post" class="lomake">
    <input type="email" name="email"placeholder = "Sähköposti" required><br><br>
    <input type="text" name="kayttaja" placeholder="Käyttäjätunnus" required><br><br>
    <input type="password" name="salasana" placeholder="Salasana (min 8)" minlength="8" required><br><br>
    <input type="submit" value="Rekisteröidy">
</form>

</body>
</html>
